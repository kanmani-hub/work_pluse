import { supabase } from '../../lib/supabase';
import { ADMIN_NOTIFICATION_ROLES } from '../../lib/roles';
import { salaryService } from '../payroll/salaryService'; // Reusing getCurrentEmployeeId
import type { EmployeeNotification } from './notificationRules';

export const notificationService = {
  async getMyNotifications() {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { data: null, error: new Error('Unauthorized') };

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_employee_id', empId)
      .order('created_at', { ascending: false });

    return { data, error };
  },

  async getMyUnreadNotifications() {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { data: null, error: new Error('Unauthorized') };

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_employee_id', empId)
      .eq('is_read', false)
      .order('created_at', { ascending: false });

    return { data, error };
  },

  async getUnreadNotificationCount() {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { count: 0, error: new Error('Unauthorized') };

    const { count, error } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('recipient_employee_id', empId)
      .eq('is_read', false);

    return { count: count || 0, error };
  },

  async markNotificationAsRead(notificationId: string) {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { error: new Error('Unauthorized') };

    // Verify ownership
    const { data: notif } = await supabase.from('notifications').select('recipient_employee_id').eq('id', notificationId).single<any>();
    if (!notif || notif.recipient_employee_id !== empId) return { error: new Error('Unauthorized') };

    const { error } = await supabase
      .from('notifications')
      .update({
        is_read: true,
        read_at: new Date().toISOString()
      } as never)
      .eq('id', notificationId);

    return { error };
  },

  async markAllNotificationsAsRead() {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { error: new Error('Unauthorized') };

    const { error } = await supabase
      .from('notifications')
      .update({
        is_read: true,
        read_at: new Date().toISOString()
      } as never)
      .eq('recipient_employee_id', empId)
      .eq('is_read', false);

    return { error };
  },

  async clearReadNotifications() {
    const empId = await salaryService.getCurrentEmployeeId();
    if (!empId) return { error: new Error('Unauthorized') };

    // Hard delete is used as per standard Supabase setups unless there's an 'is_archived' or 'deleted_at' column.
    // The instructions say "If the existing system uses soft deletion/archive: reuse it. Never delete unread notifications."
    // We will just do a standard delete on read notifications.
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('recipient_employee_id', empId)
      .eq('is_read', true);

    return { error };
  },

  // Internal/Admin API to create a notification (not directly exposed to employee actions)
  async createNotification(params: {
    recipient_employee_id: string;
    notification_type: string;
    title: string;
    message: string;
    priority?: string;
    action_url?: string;
    entity_type?: string;
    entity_id?: string;
    metadata?: any;
    expires_at?: string;
  }) {
    const { data, error } = await supabase
      .from('notifications')
      .insert({
        recipient_employee_id: params.recipient_employee_id,
        notification_type: params.notification_type,
        title: params.title,
        message: params.message,
        priority: params.priority || 'NORMAL',
        action_url: params.action_url || null,
        entity_type: params.entity_type || null,
        entity_id: params.entity_id || null,
        metadata: params.metadata || null,
        expires_at: params.expires_at || null
      } as never)
      .select()
      .single<any>();

    return { data, error };
  },

  /**
   * Notify ONE employee about something that affects them (admin decision, automatic break,
   * payroll, shift, profile, security). Idempotent: the same dedupe_key for the same employee
   * is stored once, so a double click, a second tab, a retry or GPS jitter cannot create a
   * duplicate. Never throws: a failed notification must not fail the admin action itself.
   */
  async notifyEmployee(recipientEmployeeId: string | null | undefined, n: EmployeeNotification | null, extraMetadata: Record<string, any> = {}) {
    if (!recipientEmployeeId || !n) return { data: null, error: null, skipped: true };
    try {
      const { data: existing, error: lookupError } = await supabase
        .from('notifications')
        .select('id')
        .eq('recipient_employee_id', recipientEmployeeId)
        .contains('metadata', { dedupe_key: n.dedupe_key })
        .limit(1) as any;
      if (lookupError) console.error('[NOTIFY] duplicate check failed:', lookupError.message);
      if (existing && existing.length > 0) return { data: existing[0], error: null, skipped: true };

      const { data, error } = await supabase
        .from('notifications')
        .insert({
          recipient_employee_id: recipientEmployeeId,
          notification_type: n.notification_type,
          title: n.title,
          message: n.message,
          priority: n.priority,
          action_url: n.action_url,
          entity_type: n.entity_type,
          entity_id: n.entity_id,
          metadata: { ...extraMetadata, dedupe_key: n.dedupe_key },
        } as never)
        .select()
        .single<any>();

      // With the proposed unique index on (recipient, dedupe_key) a racing duplicate is rejected here
      if ((error as any)?.code === '23505') return { data: null, error: null, skipped: true };
      if (error) console.error('[NOTIFY] notifyEmployee failed:', error.message, { recipient: recipientEmployeeId, type: n.notification_type });
      else if (import.meta.env?.DEV) console.info('[NOTIFY] stored', n.notification_type, 'for', recipientEmployeeId, data?.id);
      return { data, error, skipped: false };
    } catch (err) {
      console.error('[NOTIFY] notifyEmployee failed:', err);
      return { data: null, error: err as any, skipped: false };
    }
  },

  /**
   * Notify all Admin/HR users of a business event (e.g. new request submitted).
   * Resolves actual admin employee IDs from the DB — never uses hardcoded IDs.
   */
  async notifyAdmins(params: {
    notification_type: string;
    title: string;
    message: string;
    priority?: string;
    action_url?: string;
    entity_type?: string;
    entity_id?: string;
    metadata?: any;
  }) {
    const { data: adminRoles } = await supabase
      .from('roles')
      .select('id, name')
      .in('name', [...ADMIN_NOTIFICATION_ROLES]) as any;

    if (!adminRoles || adminRoles.length === 0) return;
    const roleIds = adminRoles.map((r: any) => r.id);

    const { data: admins } = await supabase
      .from('employees')
      .select('id')
      .in('role_id', roleIds)
      .eq('status', 'ACTIVE') as any;

    if (!admins || admins.length === 0) return;

    // Dedup: don't create if same entity already notified this admin
    const notificationsToInsert = admins.map((admin: any) => ({
      recipient_employee_id: admin.id,
      notification_type: params.notification_type,
      title: params.title,
      message: params.message,
      priority: params.priority || 'NORMAL',
      action_url: params.action_url || null,
      entity_type: params.entity_type || null,
      entity_id: params.entity_id || null,
      metadata: params.metadata || null,
    }));

    const { error } = await supabase.from('notifications').insert(notificationsToInsert as any);
    if (error) console.error('[NOTIFY] notifyAdmins insert error:', error);
  },

  // Notify Admins of Geofence Events
  async notifyGeofenceEvent(params: { event_type: string, employeeName: string, employeeCode: string, distance?: number | null, empId: string, eventId?: string }) {
    // Determine title and message
    let title = '';
    let message = '';
    
    if (params.event_type === 'EXITED') {
      title = 'Employee Left Office';
      message = `${params.employeeName} (${params.employeeCode}) has moved outside the configured office geofence.`;
    } else if (params.event_type === 'ENTERED') {
      title = 'Employee Returned to Office';
      message = `${params.employeeName} (${params.employeeCode}) has returned inside the office geofence.`;
    } else if (params.event_type === 'LOCATION_DENIED') {
      title = 'Location Permission Denied';
      message = `${params.employeeName} has denied location access.`;
    } else if (params.event_type === 'LOCATION_STALE') {
      title = 'Employee Location Stale';
      message = `${params.employeeName}'s location has not been updated for more than 5 minutes.`;
    } else {
      return; // Unhandled event type
    }

    // Deduplication check: Has this specific event (or event type for this employee in the last minute) already been notified?
    // A robust deduplication requires checking existing notifications.
    if (params.eventId) {
      const { data: existingNotif } = await supabase
        .from('notifications')
        .select('id')
        .eq('entity_id', params.eventId)
        .eq('notification_type', 'GEOFENCE')
        .limit(1);
      
      if (existingNotif && existingNotif.length > 0) return;
    }

    // 1. Fetch admins (Role = System Admin or HR)
    const { data: adminRoles } = await supabase.from('roles').select('id, name').in('name', [...ADMIN_NOTIFICATION_ROLES]) as any;
    if (!adminRoles || adminRoles.length === 0) return;
    
    const roleIds = adminRoles.map((r: any) => r.id);
    const { data: admins } = await supabase.from('employees').select('id, email, first_name').in('role_id', roleIds) as any;
    if (!admins || admins.length === 0) return;

    // 2. Filter out the employee who caused the event (if they happen to be an admin)
    const validAdmins = admins.filter((a: any) => a.id !== params.empId);
    
    // 3. Create notifications
    const notificationsToInsert = validAdmins.map((admin: any) => ({
      recipient_employee_id: admin.id,
      notification_type: 'GEOFENCE',
      title,
      message,
      priority: 'HIGH',
      action_url: '/admin/dashboard',
      entity_type: 'geofence_events',
      entity_id: params.eventId || null,
      metadata: {
        employee_id: params.empId,
        employee_code: params.employeeCode,
        event_type: params.event_type,
        distance_meters: params.distance,
        timestamp: new Date().toISOString()
      }
    }));

    if (notificationsToInsert.length > 0) {
      const { error } = await supabase.from('notifications').insert(notificationsToInsert as any);
      if (error) console.error('Failed to insert geofence notifications', error);
    }
  }
};
