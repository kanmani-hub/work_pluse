import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Hourglass, Clock, AlertTriangle, X, RefreshCw, Plus } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { overtimeService, OT_NOT_SET_UP, type OvertimeDay } from '../../services/overtime/overtimeService';
import { OT_REASON_TEXT, validateOvertimeRequest, formatHours, minutesToHours, ACTIVE_OVERTIME_STATUSES } from '../../services/overtime/overtimeRules';
import { formatDay } from '../../services/notifications/notificationRules';
import { formatShiftClock, formatCompanyTime } from '../../services/attendance/employeeDashboardRules';
import { companyDateStr } from '../../utils/companyDate';
import RecordsModal from '../../components/common/RecordsModal';
import { clickableCardProps } from '../../services/common/cardDetails';
import { myOvertimeCards, type MyOvertimeCard } from '../../services/common/myRequestCards';

const STATUS_BADGE: Record<string, string> = { PENDING: 'badge-warning', APPROVED: 'badge-success', REJECTED: 'badge-danger', CANCELLED: 'badge-gray' };

const EmployeeOvertime: React.FC = () => {
  const { employee } = useAuth();
  const [days, setDays] = useState<OvertimeDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notSetUp, setNotSetUp] = useState(false);
  const [toast, setToast] = useState('');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAttId, setSelectedAttId] = useState<string>('');
  const [hours, setHours] = useState('');
  const [reason, setReason] = useState('');
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error: err } = await overtimeService.getMyOvertimeDays(31);
    if (data) setDays(data);
    setNotSetUp(err?.message === OT_NOT_SET_UP);
    setError(err && err.message !== OT_NOT_SET_UP ? err.message : null);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    if (!employee?.id) return;
    // Live: the admin's decision shows up without a refresh (table must be in the realtime publication)
    const channel = supabase.channel(`overtime:emp_${employee.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'overtime_requests', filter: `employee_id=eq.${employee.id}` }, () => load())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `recipient_employee_id=eq.${employee.id}` }, (p: any) => {
        if (p?.new?.notification_type === 'OVERTIME') load();
      })
      .subscribe();
    const onVisible = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { document.removeEventListener('visibilitychange', onVisible); supabase.removeChannel(channel); };
  }, [employee?.id, load]);

  const requestable = useMemo(() => days.filter(d => d.estimate.eligible && (!d.request || ['REJECTED', 'CANCELLED'].includes(d.request.status))), [days]);
  const requests = useMemo(() => days.filter(d => d.request).map(d => ({ ...d.request, day: d })), [days]);
  const thisMonth = companyDateStr().slice(0, 7);
  // Cards and their detail rows come from one builder (own attendance / requests only)
  const myOt = useMemo(() => myOvertimeCards(days, thisMonth), [days, thisMonth]);
  const kpi = { pending: myOt.cards.pending.count, approvedHours: myOt.approvedHours, potentialDays: myOt.cards.requestable.count };
  const [openCard, setOpenCard] = useState<MyOvertimeCard | null>(null);

  const selectedDay = useMemo(() => days.find(d => d.attendance.id === selectedAttId) || null, [days, selectedAttId]);
  const isSelectedDuplicate = useMemo(() => Boolean(selectedDay?.request && ACTIVE_OVERTIME_STATUSES.includes(selectedDay.request.status)), [selectedDay]);

  const openRaiseModal = () => {
    setFormError('');
    setIsModalOpen(true);
    const defaultDay = requestable[0] || days[0];
    if (defaultDay) {
      setSelectedAttId(defaultDay.attendance.id);
      if (defaultDay.estimate.eligible && (!defaultDay.request || ['REJECTED', 'CANCELLED'].includes(defaultDay.request.status))) {
        setHours(String(defaultDay.estimate.potentialHours));
      } else {
        setHours('');
      }
    } else {
      setSelectedAttId('');
      setHours('');
    }
    setReason('');
  };

  const openRequest = (d: OvertimeDay) => {
    setFormError('');
    setSelectedAttId(d.attendance.id);
    setHours(String(d.estimate.potentialHours));
    setReason('');
    setIsModalOpen(true);
  };

  const handleSelectDay = (attId: string) => {
    setSelectedAttId(attId);
    setFormError('');
    const d = days.find(x => x.attendance.id === attId);
    if (d?.estimate.eligible && (!d.request || ['REJECTED', 'CANCELLED'].includes(d.request.status))) {
      setHours(String(d.estimate.potentialHours));
    } else {
      setHours('');
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDay || submitting) return;
    if (!selectedDay.estimate.eligible) {
      setFormError(selectedDay.estimate.reason ? OT_REASON_TEXT[selectedDay.estimate.reason] : 'This day is not eligible for overtime.');
      return;
    }
    if (selectedDay.request && ACTIVE_OVERTIME_STATUSES.includes(selectedDay.request.status)) {
      setFormError('An overtime request already exists for this day.');
      return;
    }
    const h = Number(hours);
    const invalid = validateOvertimeRequest(h, selectedDay.estimate.potentialHours, reason);
    if (invalid) { setFormError(invalid); return; }
    setSubmitting(true);
    const { error: err } = await overtimeService.createRequest(selectedDay.attendance.id, h, reason);
    setSubmitting(false);
    if (err) { setFormError(err.message); return; }
    setIsModalOpen(false);
    setToast('Overtime request submitted for review.');
    setTimeout(() => setToast(''), 3000);
    load();
  };

  const cancel = async (id: string) => {
    if (cancellingId) return;
    setCancellingId(id);
    const { error: err } = await overtimeService.cancelMyRequest(id);
    setCancellingId(null);
    if (err) setError(err.message); else load();
  };

  const shiftText = (d: OvertimeDay) => d.shift ? `${d.shift.name} (${formatShiftClock(d.shift.start_time)} – ${formatShiftClock(d.shift.end_time)})` : '—';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div className="page-header" style={{ marginBottom: 0, flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 className="page-title">My Overtime</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
            Extra time is not overtime until you request it and an administrator approves the hours.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
          <button className="btn btn-outline" onClick={() => { setLoading(true); load(); }}><RefreshCw size={16} /> Refresh</button>
          <button className="btn btn-primary" onClick={openRaiseModal} disabled={notSetUp}><Plus size={16} /> Raise Overtime Request</button>
        </div>
      </div>

      {notSetUp && (
        <div className="card" role="alert" style={{ borderLeft: '4px solid var(--warning)', display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
          <AlertTriangle size={20} color="var(--warning)" /> <span>{OT_NOT_SET_UP}</span>
        </div>
      )}
      {error && (
        <div className="card" role="alert" style={{ borderLeft: '4px solid var(--danger)', color: 'var(--danger)' }}>{error}</div>
      )}
      {toast && <div className="card" role="status" style={{ borderLeft: '4px solid var(--success)', color: 'var(--success)' }}>{toast}</div>}

      <div className="tracking-kpi-grid">
        <div className="tracking-kpi-card" {...clickableCardProps('Pending requests', () => setOpenCard('pending'))}><div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Pending requests</div><div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{kpi.pending}</div></div>
        <div className="tracking-kpi-card" {...clickableCardProps('Approved this month', () => setOpenCard('approved'))}><div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Approved this month</div><div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{formatHours(Math.round(kpi.approvedHours * 100) / 100)}</div></div>
        <div className="tracking-kpi-card" {...clickableCardProps('Days you can request', () => setOpenCard('requestable'))}><div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Days you can request</div><div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{kpi.potentialDays}</div></div>
      </div>

      <div className="card">
        <h3 className="card-title" style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Hourglass size={18} /> Days with possible overtime (last 31 days)</h3>
        {loading ? <div style={{ color: 'var(--text-secondary)' }}>Loading…</div> : requestable.length === 0 ? (
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>No days with work beyond your scheduled shift.</div>
        ) : (
          <div className="table-container">
            <table className="table" style={{ width: '100%', minWidth: '720px' }}>
              <thead><tr><th>Date</th><th>Shift</th><th>Scheduled</th><th>Worked</th><th>Breaks</th><th>Possible OT</th><th></th></tr></thead>
              <tbody>
                {requestable.map(d => (
                  <tr key={d.attendance.id}>
                    <td>{formatDay(d.attendance.attendance_date)}</td>
                    <td>{shiftText(d)}</td>
                    <td>{formatHours(minutesToHours(d.estimate.scheduledMinutes ?? 0))}</td>
                    <td>{formatHours(minutesToHours(d.estimate.workedMinutes))}</td>
                    <td>{formatHours(minutesToHours(d.estimate.breakMinutes))}</td>
                    <td style={{ fontWeight: 600 }}>{formatHours(d.estimate.potentialHours)}</td>
                    <td><button className="btn btn-primary" style={{ padding: '0.375rem 0.75rem', fontSize: '0.8125rem' }} disabled={notSetUp} onClick={() => openRequest(d)}>Request</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
          <h3 className="card-title" style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Clock size={18} /> My requests</h3>
          <button className="btn btn-primary" style={{ fontSize: '0.8125rem', padding: '0.375rem 0.75rem' }} disabled={notSetUp} onClick={openRaiseModal}>
            <Plus size={14} /> Raise Overtime Request
          </button>
        </div>
        {loading ? <div style={{ color: 'var(--text-secondary)' }}>Loading…</div> : requests.length === 0 ? (
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>You have not requested overtime in the last 31 days.</div>
        ) : (
          <div className="table-container">
            <table className="table" style={{ width: '100%', minWidth: '760px' }}>
              <thead><tr><th>Date</th><th>Possible</th><th>Requested</th><th>Approved</th><th>Status</th><th>Your reason</th><th>Admin remarks</th><th>Created</th><th></th></tr></thead>
              <tbody>
                {requests.map(r => (
                  <tr key={r.id}>
                    <td>{formatDay(r.work_date)}</td>
                    <td>{formatHours(Number(r.eligible_overtime_hours))}</td>
                    <td>{formatHours(Number(r.requested_overtime_hours))}</td>
                    <td style={{ fontWeight: 600 }}>{formatHours(r.status === 'APPROVED' ? Number(r.approved_overtime_hours) : 0)}</td>
                    <td><span className={`badge ${STATUS_BADGE[r.status] || 'badge-gray'}`}>{r.status}</span></td>
                    <td style={{ maxWidth: '220px', overflowWrap: 'anywhere' }}>{r.employee_reason}</td>
                    <td style={{ maxWidth: '220px', overflowWrap: 'anywhere' }}>{r.admin_remarks || '—'}</td>
                    <td style={{ fontSize: '0.75rem' }}>{r.created_at ? new Date(r.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'Asia/Kolkata' }) : '—'}</td>
                    <td>{r.status === 'PENDING' && (
                      <button className="btn btn-outline" style={{ padding: '0.25rem 0.625rem', fontSize: '0.75rem' }} disabled={cancellingId === r.id} onClick={() => cancel(r.id)}>
                        {cancellingId === r.id ? 'Cancelling…' : 'Cancel'}
                      </button>
                    )}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {!loading && days.some(d => !d.estimate.eligible && d.attendance.clock_out_at && d.estimate.reason !== 'NO_EXTRA_TIME') && (
          <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.75rem' }}>
            Some days are not eligible: {[...new Set(days.filter(d => !d.estimate.eligible && d.attendance.clock_out_at && d.estimate.reason !== 'NO_EXTRA_TIME').map(d => OT_REASON_TEXT[d.estimate.reason!]))].join(' ')}
          </p>
        )}
      </div>

      {isModalOpen && (
        <div className="drawer-overlay" style={{ alignItems: 'center', zIndex: 120 }}>
          <div className="card" style={{ margin: 'auto', width: '100%', maxWidth: '520px', animation: 'slideUp 0.3s' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 600, margin: 0 }}>Raise Overtime Request</h3>
              <button className="icon-button" onClick={() => setIsModalOpen(false)} aria-label="Close"><X size={20} /></button>
            </div>

            {days.length === 0 ? (
              <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <p>No attendance records found for the past 31 days. Overtime can only be requested for days where you clocked in and completed attendance.</p>
                <button type="button" className="btn btn-outline" onClick={() => setIsModalOpen(false)}>Close</button>
              </div>
            ) : (
              <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {requestable.length === 0 && (
                  <div role="alert" style={{ padding: '0.75rem', backgroundColor: 'var(--warning-50, #fffbeb)', border: '1px solid var(--warning-200, #fde68a)', borderRadius: 'var(--radius-md)', fontSize: '0.8125rem', color: 'var(--warning-800, #92400e)' }}>
                    <strong>No eligible overtime days found in the last 31 days.</strong> Overtime requires completing worked time beyond your scheduled shift hours and clocking out without unapproved leaves or half days.
                  </div>
                )}

                <div>
                  <label className="form-label" htmlFor="ot-work-date">Work Date</label>
                  <select
                    id="ot-work-date"
                    className="form-control"
                    value={selectedAttId}
                    onChange={e => handleSelectDay(e.target.value)}
                    disabled={submitting}
                  >
                    {days.map(d => {
                      const isDup = d.request && ACTIVE_OVERTIME_STATUSES.includes(d.request.status);
                      let label = `${formatDay(d.attendance.attendance_date)} — `;
                      if (d.estimate.eligible) {
                        label += `${formatHours(d.estimate.potentialHours)} eligible`;
                      } else if (isDup) {
                        label += `Already ${d.request.status}`;
                      } else if (d.estimate.reason) {
                        label += OT_REASON_TEXT[d.estimate.reason];
                      } else {
                        label += 'Ineligible';
                      }
                      return <option key={d.attendance.id} value={d.attendance.id}>{label}</option>;
                    })}
                  </select>
                </div>

                {selectedDay && (
                  <div style={{ backgroundColor: 'var(--bg-surface, #f9fafb)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '0.875rem', fontSize: '0.8125rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div>
                      <span style={{ color: 'var(--text-secondary)' }}>Scheduled Shift:</span>{' '}
                      <strong>{shiftText(selectedDay)}</strong>{' '}
                      ({formatHours(minutesToHours(selectedDay.estimate.scheduledMinutes ?? 0))} scheduled)
                    </div>
                    <div>
                      <span style={{ color: 'var(--text-secondary)' }}>Actual Attendance:</span>{' '}
                      In: <strong>{formatCompanyTime(selectedDay.attendance.clock_in_at)}</strong> · Out: <strong>{formatCompanyTime(selectedDay.attendance.clock_out_at)}</strong> · Worked: <strong>{formatHours(minutesToHours(selectedDay.estimate.workedMinutes))}</strong>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>Overtime Status:</span>{' '}
                      {selectedDay.estimate.eligible ? (
                        <span style={{ color: 'var(--success)', fontWeight: 600 }}>{formatHours(selectedDay.estimate.potentialHours)} eligible</span>
                      ) : (
                        <span style={{ color: 'var(--danger)' }}>{selectedDay.estimate.reason ? OT_REASON_TEXT[selectedDay.estimate.reason] : 'Not eligible'}</span>
                      )}
                      {selectedDay.request && (
                        <span className={`badge ${STATUS_BADGE[selectedDay.request.status] || 'badge-gray'}`}>
                          Existing: {selectedDay.request.status} ({selectedDay.request.requested_overtime_hours}h)
                        </span>
                      )}
                    </div>
                    {isSelectedDuplicate && (
                      <div style={{ color: 'var(--warning-800, #92400e)', backgroundColor: 'var(--warning-50, #fffbeb)', padding: '0.375rem 0.5rem', borderRadius: 'var(--radius-sm)', fontSize: '0.75rem' }}>
                        An overtime request for this date already exists ({selectedDay.request.status}). Duplicate requests are not permitted.
                      </div>
                    )}
                  </div>
                )}

                {formError && (
                  <div role="alert" style={{ padding: '0.75rem', backgroundColor: 'var(--danger-50)', color: 'var(--danger)', borderRadius: 'var(--radius-md)', fontSize: '0.875rem' }}>
                    {formError}
                  </div>
                )}

                <div>
                  <label className="form-label" htmlFor="ot-hours">
                    Requested Overtime Hours {selectedDay?.estimate.eligible ? `(max ${selectedDay.estimate.potentialHours})` : ''}
                  </label>
                  <input
                    id="ot-hours"
                    type="number"
                    min="0.01"
                    step="0.01"
                    max={selectedDay?.estimate.eligible ? selectedDay.estimate.potentialHours : undefined}
                    className="form-control"
                    value={hours}
                    onChange={e => setHours(e.target.value)}
                    disabled={submitting || !selectedDay?.estimate.eligible || isSelectedDuplicate}
                    placeholder="e.g. 1.50"
                  />
                </div>

                <div>
                  <label className="form-label" htmlFor="ot-reason">Reason *</label>
                  <textarea
                    id="ot-reason"
                    className="form-control"
                    rows={3}
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    disabled={submitting || !selectedDay?.estimate.eligible || isSelectedDuplicate}
                    placeholder="What project or deliverables did you work on?"
                  />
                </div>

                <div style={{ display: 'flex', gap: '1rem' }}>
                  <button type="button" className="btn btn-outline" style={{ flex: 1 }} onClick={() => setIsModalOpen(false)} disabled={submitting}>
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    style={{ flex: 1 }}
                    disabled={submitting || !selectedDay?.estimate.eligible || isSelectedDuplicate}
                  >
                    {submitting ? 'Submitting…' : 'Submit Overtime Request'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
      <style>{`@keyframes slideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`}</style>
      {openCard && (() => {
        const meta: Record<MyOvertimeCard, [string, React.ReactNode, string, string]> = {
          pending: ['Pending Overtime Requests', myOt.cards.pending.count, 'Requests', 'Your overtime requests waiting for an admin decision.'],
          approved: [`Overtime Approved — ${thisMonth}`, formatHours(Math.round(myOt.approvedHours * 100) / 100), `Approved hours (${myOt.cards.approved.count} requests)`, 'Sum of the hours the admin approved for work dates this month. Requested or possible hours are never counted.'],
          requestable: ['Days You Can Request', myOt.cards.requestable.count, 'Days', 'Recent days where your worked time after the shift is eligible and no active request exists.'],
        };
        const [title, total, label, explain] = meta[openCard];
        return <RecordsModal open title={title} total={total} totalLabel={label}
          columns={[{ key: 'date', label: 'Work Date' }, { key: 'shift', label: 'Shift' }, { key: 'clockIn', label: 'Clock In' }, { key: 'clockOut', label: 'Clock Out' },
            { key: 'possible', label: 'Possible', align: 'right', format: (v: any) => formatHours(v) }, { key: 'requested', label: 'Requested', align: 'right', format: (v: any) => (v === null ? '—' : formatHours(v)) },
            { key: 'approved', label: 'Approved', align: 'right', format: (v: any) => (v === null ? '—' : formatHours(v)) }, { key: 'status', label: 'Status' }]}
          rows={myOt.cards[openCard].rows} loading={loading} error={error} emptyMessage="No matching overtime records."
          explanation={[explain, 'Overtime pay is calculated in payroll using the company’s configured rate. Only your own records are shown.']} onClose={() => setOpenCard(null)} />;
      })()}
    </div>
  );
};

export default EmployeeOvertime;
